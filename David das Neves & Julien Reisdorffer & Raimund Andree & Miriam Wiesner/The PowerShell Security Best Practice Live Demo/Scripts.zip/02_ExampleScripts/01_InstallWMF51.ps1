<#  
        .NOTES 
        ============================================================================
        Date:       20.04.2018
        Presenter:  David das Neves 
        Version:    1.0
        Project:    PSConfEU - Demo 
        Ref:        

        ============================================================================ 
        .DESCRIPTION 
        Presentation data        

#> 

Import-Lab PSSecDemoLab

#Copies Software package
# You need to download a .NET version - we used 'NDP462-KB3151800-x86-x64-AllOS-ENU.exe'
# You need to download WMF 5.1 - we used 'Win7AndW2K8R2-KB3191566-x64.msu'
Copy-LabFileItem -Path $labSources\SoftwarePackages\NDP462-KB3151800-x86-x64-AllOS-ENU.exe -DestinationFolderPath 'C:\temp\' -ComputerName 'W7-1'
Copy-LabFileItem -Path $labSources\SoftwarePackages\Win7AndW2K8R2-KB3191566-x64.msu  -DestinationFolderPath 'C:\temp\' -ComputerName 'W7-1'




#Remote Installation
Install-LabSoftwarePackage -Path $labSources\SoftwarePackages\NDP462-KB3151800-x86-x64-AllOS-ENU.exe -CommandLine '/q /log c:\dotnet452.txt' -ComputerName W7-1 -AsScheduledJob -UseShellExecute
Install-LabSoftwarePackage -Path $labSources\SoftwarePackages\Win7AndW2K8R2-KB3191566-x64.msu -ComputerName W7-1
Restart-LabVM -ComputerName W7-1 

