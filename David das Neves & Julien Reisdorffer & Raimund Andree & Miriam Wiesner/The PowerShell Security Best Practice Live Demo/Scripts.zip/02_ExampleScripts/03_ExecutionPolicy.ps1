<#  
        .NOTES 
        ============================================================================
        Date:       20.04.2018
        Presenter:  David das Neves 
        Version:    1.0
        Project:    PSConfEU - Demo 
        Ref:        

        ============================================================================ 
        .DESCRIPTION 
        Presentation data        
#> 
#Enter Session
Enter-LabPSSession w10-1

#Get
Get-ExecutionPolicy

#Execute the script
. C:\temp\02_SigningTest.ps1

#Set to AllSigned
Set-ExecutionPolicy -ExecutionPolicy AllSigned

#Execute the script
. C:\temp\02_SigningTest.ps1

#Even though the script is signed, Windows doesn’t run the script unprompted, 
#as currently it does not trust the publisher. To trust the publisher and not 
#get prompted each time, select A for Always run. This puts the certificate in 
#the Trusted Publishers certificate store. 

#Around the Execution Policy
powershell.exe -command  $(Get-Content C:\temp\02_SigningTest.ps1 -Raw )

