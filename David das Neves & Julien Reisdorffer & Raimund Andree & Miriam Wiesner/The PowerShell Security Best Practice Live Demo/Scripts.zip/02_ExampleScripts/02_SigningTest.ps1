﻿$ExecutionContext.SessionState.LanguageMode 

New-Object Net.WebClient 

(Get-Service)[2]

