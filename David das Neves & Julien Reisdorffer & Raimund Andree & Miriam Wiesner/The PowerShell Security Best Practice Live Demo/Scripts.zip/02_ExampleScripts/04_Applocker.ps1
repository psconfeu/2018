<#  
        .NOTES 
        ============================================================================
        Date:       20.04.2018
        Presenter:  David das Neves 
        Version:    1.0
        Project:    PSConfEU - Demo 
        Ref:        

        ============================================================================ 
        .DESCRIPTION 
        Presentation data        
#> 

#Imports lab
Import-Lab PSSecDemoLab

#Installs Software package
Copy-LabFileItem -Path .\04_ConstrainedLanguageScript.ps1  -DestinationFolderPath 'C:\temp\' -ComputerName 'W10-1'

#Enter Session
Enter-LabPSSession w10-1

#Execute Script 
C:\temp\04_ConstrainedLanguageScript.ps1

#Sign Script
Get-Item -Path 'C:\temp\04_ConstrainedLanguageScript.ps1'| Set-AuthenticodeSignature -Certificate $cert

#Execute Script 
C:\temp\04_ConstrainedLanguageScript.ps1

#Local GPOs switching

#Execute Script 
C:\temp\04_ConstrainedLanguageScript.ps1

#Create specific folde
mkdir c:\Skripte\

#Copy 
Copy-Item C:\temp\04_ConstrainedLanguageScript.ps1 c:\Skripte\

#Take a look
cd c:\skripte\
psedit C:\temp\04_ConstrainedLanguageScript.ps1 

