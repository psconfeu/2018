﻿<#  
        .NOTES 
        ============================================================================
        Date:       20.04.2018
        Presenter:  David das Neves 
        Version:    1.0
        Project:    PSConfEU - Demo 
        Ref:        

        ============================================================================ 
        .DESCRIPTION 
        Presentation data        
#> 

#Create Cert

#Copyjob
Copy-LabFileItem -Path .\02_SigningTest.ps1  -DestinationFolderPath 'C:\temp\' -ComputerName 'W10-1'

#Enter Session
Enter-LabPSSession w10-1

#Go to certificate store
Set-Location -Path Cert:\CurrentUser\My

#Gather the code certificate
$cert = Get-ChildItem -CodeSigningCert -Recurse

#Signing
Get-Item -Path 'c:\temp\02_SigningTest.ps1' | Set-AuthenticodeSignature -Certificate $cert

#Info
Get-AuthenticodeSignature -FilePath 'c:\temp\02_SigningTest.ps1' | select *
