﻿#########################################################
# This is a configuration script to demonstrate how to convert
# Microsoft Security Baselines and to check via DSCEA if your systems are
# already aligned to the baseline
#
# Used in the Session 'The PowerShell Security Best Practice Live Demo'
#
# Author: Miriam Wiesner
# Creation date: 16.04.2018
# Version: 1.0.0

####################### VARIABLES #######################

#Prerequisites: Download the Security Compliance Toolkit from Microsoft to get the baselines
#https://www.microsoft.com/en-us/download/details.aspx?id=55319

#where are the Baseline GPOs located
$gpoPath = 'C:\SCT\W10V1607+WSrv2016\Windows-10-RS1-and-Server-2016-Security-Baseline\GPOs'
$dsceaPath = 'C:\Program Files\WindowsPowerShell\Modules\DSCEA\1.2.0.0'

#Member Server GPO UID (replace with a UID of your choice)
$gpoUID = '{088E04EC-440C-48CB-A8D7-A89D0162FBFB}'

#########################################################

#Install the DSCEA Module
Install-Module -Name DSCEA

#Review Config Files
Set-Location $dsceaPath
powershell_ise .\configs\SampleConfig.ps1

#Generate DSCEA sample config
.\configs\SampleConfig.ps1

#Generate Report
Start-DSCEAscan -ComputerName 'localhost' -MofFile 'localhost.mof'
Get-DSCEAreport -Detailed

#Open Report
Invoke-Item .\DetailedComplianceReport.html

#########################################################

#Now combine with Baselines

#Install Baseline Mgmt: say yes to install the required additional stuff
Install-Module -Name BaselineManagement

#Convert Member Server Baselines to a mof-file (ready for DSC)
ConvertFrom-GPO -Path $gpoPath\$gpoUID -OutputConfigurationScript 

#Start the scan to see if your systems are aligned to the baseline
Start-DSCEAscan -MofFile $dsceaPath\Output\localhost.mof -ComputerName localhost

#Generate the report
Get-DSCEAreport -ComputerName localhost
Invoke-Item .\ComputerComplianceReport-localhost.html


