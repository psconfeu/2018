
# This is an installation script for the demo environment used in the Session 'The PowerShell Security Best Practice Live Demo'
# Authors: Julien Reisdorffer, David das Neves
# Creation date: 10.04.2018
# Version: 1.0.0

$labName = 'PSSecDemoLab'

#create an empty lab template and define where the lab XML files and the VMs will be stored
New-LabDefinition -Name $labName -DefaultVirtualizationEngine HyperV

# Deploy to Azure
#New-LabDefinition -Name $labName -DefaultVirtualizationEngine Azure
#Add-LabAzureSubscription -SubscriptionName 

#make the network definition
Add-LabVirtualNetworkDefinition -Name $labName -AddressSpace 192.168.42.0/24

#and the domain definition with the domain admin account
Add-LabDomainDefinition -Name PSSec.net -AdminUser Install -AdminPassword Somepass1

#Installation credentials
Set-LabInstallationCredential -Username Install -Password Somepass1

#defining default parameter values, as these ones are the same for all the machines
$PSDefaultParameterValues = @{
    'Add-LabMachineDefinition:Network' = $labName
    'Add-LabMachineDefinition:ToolsPath'= "$labSources\Tools"
       'Add-LabMachineDefinition:DnsServer1'= '192.168.42.10'
    'Add-LabMachineDefinition:Memory'= 512MB
    'Add-LabMachineDefinition:DomainName'= 'pssec.net'
    'Add-LabMachineDefinition:OperatingSystem'= 'Windows Server 2016 Standard (Desktop Experience)'
}

#the first server is the root domain controller. Everything in $labSources\Tools get copied to the machine's Windows folder
$role = Get-LabMachineRoleDefinition -Role RootDC 

#DC
Add-LabMachineDefinition -Name DC1 -IpAddress 192.168.42.10 -Roles $role 

#the second will be a member server configured as Root CA server. Everything in $labSources\Tools get copied to the machine's Windows folder
#TODO Algo pr�fen ggf. manuell erstellen
$role = Get-LabMachineRoleDefinition -Role CaRoot @{ 
       CACommonName        = "MySpecialRootCA1"
    KeyLength           = "2048"
    ValidityPeriod      = "Weeks"
    ValidityPeriodUnits = "4"
} 

#CA
Add-LabMachineDefinition -Name CA1 -IpAddress 192.168.42.20 -Roles $role

#Server
Add-LabMachineDefinition -Name SRV1 -IpAddress 192.168.42.21 
Add-LabMachineDefinition -Name SRV2 -IpAddress 192.168.42.22

#Clients
Add-LabMachineDefinition -Name W7-1 -IpAddress 192.168.42.31  -OperatingSystem 'Windows 7 Professional' 
Add-LabMachineDefinition -Name W10-1 -IpAddress 192.168.42.32 -OperatingSystem 'Windows 10 Pro'
Add-LabMachineDefinition -Name W10-2 -IpAddress 192.168.42.33 -OperatingSystem 'Windows 10 Pro'
Add-LabMachineDefinition -Name W10-3 -IpAddress 192.168.42.34 -OperatingSystem 'Windows 10 Pro'

#Installs lab
Install-Lab 

#Enroll certificate
Enable-LabCertificateAutoenrollment -Computer -User -CodeSigning

#Install software to all lab machines
$machines = Get-LabVM
Install-LabSoftwarePackage -ComputerName $machines -Path $labSources\SoftwarePackages\Notepad++.exe -CommandLine /S -AsJob
Get-Job -Name 'Installation of*' | Wait-Job | Out-Null

#Shows the summary
Show-LabDeploymentSummary -Detailed 

