﻿#########################################################
# This is a JEA configuration script demonstrate the local virtual 
# accounts created during the session
#
# Used in the Session 'Securing your infrastructure with JEA'
#
# Author: Miriam Wiesner
# Creation date: 13.04.2018
# Version: 1.0.0

#########################################################

#Local Users: No JEA Account
Get-LocalUser

#This is where the magic happens
(GET-WMIOBJECT win32_process).GetOwner().User