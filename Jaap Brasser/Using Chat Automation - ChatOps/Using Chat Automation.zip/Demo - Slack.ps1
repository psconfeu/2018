
$WebHookSplat = @{
    Method = 'post'
    ContentType = 'Application/Json'
    Body = '{"text":"Hello PSConf Europe!"}'
    Uri = 'https://hooks.slack.com/services/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'
}

Invoke-RestMethod @WebHookSplat

$WebHookSplat.Body = @'
{
    "attachments": [
        {
            "color": "00ff00",
            "pretext": "Optional text that appears above the attachment block",
            "title": "Slack attachment example",
            "text": "Optional text that appears within the attachment",
            "fields": [
                {
                    "title": "Priority",
                    "value": "High",
                    "short": false
                }
            ]
        }
    ]
}
'@

Invoke-RestMethod @WebHookSplat

$SysErrors = (get-eventlog -LogName System -EntryType Error -After 4-1-2018 | Measure-Object).Count
$SysWarnings = (get-eventlog -LogName System -EntryType Warning -After 4-1-2018 | Measure-Object).Count
$WebHookSplat.Body = @"
{
    "attachments": [
        {
            "color": "ff0000",
            "title": "Slack attachment example",
            "text": "Optional text that appears within the attachment",
            "fields": [
                {
                    "title": "Security log errors",
                    "value": "$SysErrors",
                    "short": false
                }
            ]
        },
        {
            "color": "ffff00",
            "title": "Slack attachment example",
            "text": "Optional text that appears within the attachment",
            "fields": [
                {
                    "title": "Security log warnings",
                    "value": "$SysWarnings",
                    "short": false
                }
            ]
        },
    ]
}
"@
Invoke-RestMethod @WebHookSplat

$SlackMessage = @{
    Uri = 'https://hooks.slack.com/services/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' 
    Text = 'Hello PSConfEU!'
}
Send-SlackMessage @SlackMessage

Get-Command -Module PSSlack
