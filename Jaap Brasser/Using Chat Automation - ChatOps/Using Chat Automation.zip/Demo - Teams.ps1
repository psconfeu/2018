# Show setting up the webhook connector

# First message
$WebHookSplat = @{
    Method = 'post'
    ContentType = 'Application/Json'
    Body = '{"text":"Hello PSConf Europe!"}'
    Uri = 'https://outlook.office.com/webhook/73c3273b-7533-4fef-b4fb-3e72dc28524e@306c6071-8dcf-47fb-a546-8a7074ad0f19/IncomingWebhook/506537459c21425080cf60f7b8e5ba0e/448c7c77-f778-43f0-a41c-640710d8a2bd'
}
Invoke-RestMethod @WebHookSplat

$WebHookSplat.Body = @'
{
    "@type": "MessageCard",
    "@context": "http://schema.org/extensions",
    "summary": "Using Chat Automation",
    "title": "PowerShell Conference Europe",
    "sections": [
        {
            "activityTitle": "Jaap is presenting",
            "activitySubtitle": "On Chat Automation",
            "activityText": "\"Incoming webhook\"",
            "activityImage": "https://upload.wikimedia.org/wikipedia/commons/2/2f/PowerShell_5.0_icon.png"
        }
    ]
}
'@
Invoke-RestMethod @WebHookSplat

$WebHookSplat.Body = @'
{
    "@type": "MessageCard",
    "@context": "http://schema.org/extensions",
    "summary": "Using Chat Automation",
    "title": "PowerShell Conference Europe",
    "sections": [
        {
            "activityTitle": "Jaap is presenting",
            "activitySubtitle": "On Chat Automation",
            "activityText": "\"Incoming webhook\"",
            "activityImage": "https://upload.wikimedia.org/wikipedia/commons/2/2f/PowerShell_5.0_icon.png"
        }
    ]
}
'@
Invoke-RestMethod @WebHookSplat


$SysErrors = (get-eventlog -LogName System -EntryType Error -After 4-1-2018 | Measure-Object).Count
$SysWarnings = (get-eventlog -LogName System -EntryType Warning -After 4-1-2018 | Measure-Object).Count
$WebHookSplat.Body = @"
{
    "@type": "MessageCard",
    "@context": "http://schema.org/extensions",
    "summary": "Using Chat Automation",
    "title": "PowerShell Conference Europe",
    "sections": [
        {
            "activityTitle": "Security Log",
            "activitySubtitle": "Number of errors:",
            "activityText": "$($SysErrors)",
            "activityImage": "https://upload.wikimedia.org/wikipedia/commons/2/2f/PowerShell_5.0_icon.png"
        }
    ]
}
"@
Invoke-RestMethod @WebHookSplat

# Microsoft <3 Linux
curl -H "Content-Type: application/json" -d "{\"text\": \"Hello PSConf Europe!\"}"
 https://outlook.office.com/webhook/73c3273b-7533-4fef-b4fb-3e72dc28524e@306c6071
 -8dcf-47fb-a546-8a7074ad0f19/IncomingWebhook/f1483aa388724c099f7ad9aca956066c/
 448c7c77-f778-43f0-a41c-640710d8a2bd
