function Invoke-PSRemoting {
    $Session = New-PSSession -ComputerName . -Credential $Cred
    Invoke-Command -Session $Session {
        Get-Service wuauserv
    } | Select Status,Name,DisplayName
}

function Invoke-PsExec {
    $Output = C:\SysinternalsSuite\PsExec.exe `
        -nobanner -s powershell.exe -nop -ex bypass -OutputFormat XML `
        -c "& {`
            Get-Service wuauserv | Select Status,Name,DisplayName
    }" 2> $null

    return $Output
}

function Invoke-WmiExecution {
    $WmiProc = [wmiclass]'win32_process'
    $WmiProc.Scope.Path = "\\PSConfEU\root\cimv2"
    $Results = $WmiProc.Create(
        'powershell.exe -nop -ex bypass -c "& {
            Get-Service wuauserv | Export-CliXml /temp/Object.Xml
            $ByteArr = Get-Content /temp/object.xml -Encoding Byte -Readcount 0
            New-ItemProperty -Path HKLM:\SOFTWARE\PSConfEU -Name Object -Value $ByteArr -PropertyType Binary -Force
        }"'
    )

    Start-Sleep -Seconds 1

    # MSDN GetBinaryValue: https://msdn.microsoft.com/en-us/library/aa390440(v=vs.85).aspx
    $H = @{
        hklm  = 2147483650
        key   = "SOFTWARE\PSConfEU"
        value = "Object"
    }

    $wmi = [wmiclass]"\\PSConfEU\root\default:stdRegProv"
    $LocalBytes = ($wmi.GetBinaryValue($H.hklm,$H.key,$H.value)).uvalue

    $FileName = [io.path]::GetRandomFileName()
    [io.file]::WriteAllBytes($FileName, $LocalBytes)

    Import-CliXml -Path $FileName | Select Status,Name,DisplayName

    Remove-Item $FileName -Force
}


Write-Verbose -Message 'PSRemoting' -Verbose
Invoke-PSRemoting

Write-Verbose -Message 'PSExec' -Verbose
Invoke-PSExec

Write-Verbose -Message 'Wmi' -Verbose
Invoke-WmiExecution

Invoke-PSRemoting | gm
Invoke-PSExec | gm
Invoke-WmiExecution | gm