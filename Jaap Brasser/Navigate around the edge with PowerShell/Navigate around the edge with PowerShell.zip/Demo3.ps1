# Retrieve Base64 Encoded CliXml file
$Output = C:\SysinternalsSuite\PsExec.exe `
    -nobanner -s powershell.exe -nop -ex bypass `
    -c "& {`
        Get-Service wuauserv | Export-CliXml C:\Temp\PSExec.xml `
        `$RemoteBytes = [io.file]::ReadAllBytes('C:\Temp\PSExec.xml')`
        [convert]::ToBase64String(`$RemoteBytes)`
}" 2> $null
$Output.GetType()
$Output | Select-Object *

# Use PowerShell.exe -OutputFormat
C:\SysinternalsSuite\PsExec.exe `
-nobanner -s powershell.exe -nop -ex bypass -OutputFormat XML `
-c "& {`
    Get-Service wuauserv
}" 2> $null

# Turn it into a PowerShell object
$(C:\SysinternalsSuite\PsExec.exe `
-nobanner -s powershell.exe -nop -ex bypass -OutputFormat XML `
-c "& {`
    Get-Service wuauserv
}" 2> $null)

# Save to variable
$Output = C:\SysinternalsSuite\PsExec.exe `
-nobanner -s powershell.exe -nop -ex bypass -OutputFormat XML `
-c "& {`
    Get-Service wuauserv
}" 2> $null

$Output.GetType()
$Output
$Output | Select-Object *

$Computer = C:\SysinternalsSuite\PsExec.exe `
-nobanner -s powershell.exe -nop -ex bypass -OutputFormat XML `
-c "& {`
    Get-WmiObject -Class Win32_OperatingSystem
}" 2> $null

$Computer
$Computer | Get-Member
$Computer.Reboot()

gwmi Win32_OperatingSystem | gm -MemberType method

# Result: Now we have (deserialized) PowerShell objects without using PowerShell remoting