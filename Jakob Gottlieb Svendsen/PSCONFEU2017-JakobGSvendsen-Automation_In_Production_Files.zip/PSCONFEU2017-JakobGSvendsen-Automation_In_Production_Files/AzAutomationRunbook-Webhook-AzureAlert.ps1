pram(
    $webhookData
)

#Test data
$j = @"
{"WebhookName":"Alert1523520158621","RequestBody":"{\"schemaId\":\"AzureMonitorMetricAlert\",\"data\":{\r\n \"version\": \"2.0\",\r\n \"status\": \"Activated\",\r\n \"context\": {\r\n \"timestamp\": \"2018-04-12T13:52:54.6197056Z\",\r\n \"id\": \"/subscriptions/7fa4f2ea-77cd-4629-8fb0-42988a97b934/resourceGroups/OMS-RG/providers/microsoft.insights/metricAlerts/Automation%20Account%20-%20Test-Error\",\r\n \"name\": \"Automation Account - Test-Error\",\r\n \"description\": \"\",\r\n \"conditionType\": \"SingleResourceMultipleMetricCriteria\",\r\n \"condition\": {\r\n \"windowSize\": \"PT1M\",\r\n \"allOf\": [\r\n {\r\n \"metricName\": \"TotalJob\",\r\n \"dimensions\": [\r\n {\r\n \"name\": \"ResourceId\",\r\n \"value\": \"/subscriptions/7fa4f2ea-77cd-4629-8fb0-42988a97b934/resourceGroups/OMS-RG/providers/Microsoft.Automation/automationAccounts/Automation\"\r\n },\r\n {\r\n \"name\": \"Runbook\",\r\n \"value\": \"Test-Error2\"\r\n },\r\n {\r\n \"name\": \"Status\",\r\n \"value\": \"Failed\"\r\n }\r\n ],\r\n \"operator\": \"GreaterThan\",\r\n \"threshold\": \"0\",\r\n \"timeAggregation\": \"PT1M\",\r\n \"metricValue\": 1.0\r\n }\r\n ]\r\n },\r\n \"subscriptionId\": \"7fa4f2ea-77cd-4629-8fb0-42988a97b934\",\r\n \"resourceGroupName\": \"OMS-RG\",\r\n \"resourceName\": \"Automation\",\r\n \"resourceType\": \"Microsoft.Automation/automationAccounts\",\r\n \"resourceId\": \"/subscriptions/7fa4f2ea-77cd-4629-8fb0-42988a97b934/resourceGroups/OMS-RG/providers/Microsoft.Automation/automationAccounts/Automation\",\r\n \"portalLink\": \"https://portal.azure.com/#resource//subscriptions/7fa4f2ea-77cd-4629-8fb0-42988a97b934/resourceGroups/OMS-RG/providers/Microsoft.Automation/automationAccounts/Automation\"\r\n },\r\n \"properties\": {}\r\n}}","RequestHeader":{"Expect":"100-continue","Host":"s1events.azure-automation.net","User-Agent":"IcMBroadcaster/1.0","X-CorrelationContext":"RkkKACgAAAACAAAAEABBd4J7gO3rQIBEu0YVF3tfAQAQAMt+vIwNWqNHtGQet78H+wA=","x-ms-request-id":"c95ed062-9926-4570-9057-48cc632973f4"}}
"@

$webhookData = $j | convertfrom-json

$requestBody = ConvertFrom-JSON -InputObject $WebhookData.RequestBody
$timeActivated = $RequestBody.data.context.timestamp
$ruleName = $RequestBody.data.context.name
$accountName = $RequestBody.data.context.resourceName
$resourceGroupNAme = $RequestBody.data.context.resourceGroupName
$runbookName = $RequestBody.data.context.condition.allOf.dimensions | Where-Object Name -eq "Runbook" | Select-Object -ExpandProperty value
$runbookStatus = $RequestBody.data.context.condition.allOf.dimensions | Where-Object Name -eq "Status" | Select-Object -ExpandProperty value

