$requestBody = Get-Content $req -Raw | ConvertFrom-Json

#Log Request inputs & Body content
(Get-Variable REQ_* | Out-String)
($requestBody.Value | Format-List * | Out-String)

#If a validation token is present, we need to respond within 5 seconds.
if ($REQ_QUERY_JOBID -eq $null)
{
    throw "no job id received"
}

#generate body from job id in url
$Body = @{"JobId" = $REQ_QUERY_JOBID } | ConvertTo-Json

#Trigger Runbook in Azure Automation
$TokenEncoded = [System.Web.HttpUtility]::UrlEncode($req_query_token)

$Uri = "https://s9events.azure-automation.net/webhooks?token=$TokenEncoded"
$result = Invoke-WebRequest -Uri $Uri  -Method Post -Body $Body -ContentType "application/json" -UseBasicParsing
$result
$Content = $result.Content | ConvertFrom-JSON
#req_query_JobId

Out-File -Encoding Ascii -FilePath $res -inputObject @"
{
    "result": "Job succesfully triggered: JobIds=$($Content.JobIds -join ', ')",
}
"@
<#@"
Job Id: $($result.JobId)<br/>
Click <a href="xxx&JobId=$($result.JobId)">here</a> to rerun job"
"@#>