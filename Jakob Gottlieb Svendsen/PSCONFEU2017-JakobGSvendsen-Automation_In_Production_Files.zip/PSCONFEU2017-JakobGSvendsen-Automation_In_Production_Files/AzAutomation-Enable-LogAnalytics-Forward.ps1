Connect-AzureRmAccount
$Resource = Find-AzureRmResource -ResourceType "Microsoft.Automation/automationAccounts" -Name "Automation" | Where-Object Name -eq "Automation"

Get-AzureRmDiagnosticSetting -ResourceId $Resource.ResourceId
Set-AzureRmDiagnosticSetting -Categories 