param($webhookdata)
$ErrorActionPreference = "Stop"

<#DEbug
$webhookdata = @"
{"WebhookName":"FunctionReRunJob","RequestBody":"{\r\n \"JobId\": \"4bc1db9c-3ef3-4b29-a112-a14f9b8a3895\"\r\n}","RequestHeader":{"Connection":"Keep-Alive","Host":"s9events.azure-automation.net","User-Agent":"Mozilla/5.0","x-ms-request-id":"4bfb8d1b-1511-448a-a571-fb274f69759a"}}
"@ | ConvertFrom-JSON
#>

$body = $webhookdata.RequestBody | COnvertFrom-JSON
$JobId = $body.JobId
$JobId

Function Get-AzureRMAutomationJobResource {
    param($AutomationAccountName, $ResourceGroupName, $JobId) 
    # GET 027994dd-1be5-4db5-940b-356c4a2ff503
    $resource = Get-AzureRmResource -ResourceGroupName $ResourceGroupName -ResourceType Microsoft.Automation/automationAccounts/jobs -ResourceName "$AutomationAccountName/$JobId" -ApiVersion 2015-10-31
    return $resource.Properties
}

$connectionName = "AzureRunAsConnection"
try {
    # Get the connection "AzureRunAsConnection "
    $servicePrincipalConnection = Get-AutomationConnection -Name $connectionName         

    "Logging in to Azure..."
    Add-AzureRmAccount `
        -ServicePrincipal `
        -TenantId $servicePrincipalConnection.TenantId `
        -ApplicationId $servicePrincipalConnection.ApplicationId `
        -CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint 
}
catch {
    if (!$servicePrincipalConnection) {
        $ErrorMessage = "Connection $connectionName not found."
        throw $ErrorMessage
    }
    else {
        Write-Error -Message $_.Exception
        throw $_.Exception
    }
}

#Test
#Login-AzureRmAccount
#Select-AzureRmSubscription -SubscriptionName "Coretech Production Dashboard"
#$JobId = "4bc1db9c-3ef3-4b29-a112-a14f9b8a3895"
if ($JobId -ne $null) {
    #Select Account

    $AutomationAccountName = "OMS-RG"
    $ResourceGroupName = "Automation"
    $AutomationAccount = Get-AzureRMAutomationAccount -Name $AutomationAccountName -ResourceGroupName $ResourceGroupName

    $Job = Get-AzureRMAutomationJobResource -ResourceGroupName $AutomationAccount.ResourceGroupName -AutomationAccountName $AutomationAccount.AutomationAccountName -JobId $JobId
    $parameters = $Job.parameters
    
    # Convert the PSCustomObject back to a hashtable
    $ht2 = @{}
    foreach ($property in $parameters.psobject.properties) { 
        $ht2[$property.Name] = $property.Value | ConvertFrom-JSON 
    }
    
    Start-AzureRmAutomationRunbook -Name $Job.runbook.name -Parameters $ht2 -ResourceGroupName $AutomationAccount.ResourceGroupName -AutomationAccountName $AutomationAccount.AutomationAccountName
}

