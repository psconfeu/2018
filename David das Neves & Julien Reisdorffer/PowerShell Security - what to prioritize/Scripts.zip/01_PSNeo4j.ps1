#region setting modules and functions up

# PSNeo4j
Import-Module psneo4j

# Show the commands
Get-Command -Module PSNeo4j

# Install ImportExcel to read the Excel document
Install-Module Importexcel

# Show the commands
Get-Command -Module ImportExcel

# Gathering the tables from Excel

#Function to retrieve the data from the Excel file
function Get-ExcelDataFromWorksheet ($folder, $workSheet) {
    ConvertFrom-ExcelData -Path $folder -WorkSheetname $workSheet -scriptBlock {
        param($propertyNames, $record)
        #Only retrieving filled rows
        if ($($record.Name)) {
            $record      
        }
    }
}
#endregion

#gathering data from Excel for the PowerShell worksheet - keep xlsx file closed!
$excelData = Get-ExcelDataFromWorksheet -folder $folder -workSheet 'PowerShell'

#region Neo4j

#region Connect to Neo4j

# Password into a secure string
$Password = ConvertTo-SecureString -String "PSPrio" -AsPlainText -Force

# Create credentials - neo4j
$Cred = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList neo4j, $password

# Sets the configuration to connect to Neo4j
Set-PSNeo4jConfiguration -Credential $Cred -BaseUri 'http://127.0.0.1:7474'

# Retrieve the connected use
Get-Neo4jUser

#endregion


#region demonstration for relationships

#Relationship
New-Neo4jRelationship -LeftQuery "MATCH (left:Topic) WHERE left.Name = 'PowerShell'" `
    -RightQuery "MATCH (right:TechnalSecurityControl) WHERE right.Tag =~ 'PowerShell.*'" `
    -Type 'TopicOf' `
    -Properties @{
    Connection = $True
}

#Left Match
Invoke-Neo4jQuery -Query @"
    MATCH (n) WHERE n.Name = 'PowerShell' RETURN n
"@ |Out-GridView

#Right Match
Invoke-Neo4jQuery -Query @"
    MATCH (n) WHERE n.Tag =~ 'PowerShell.*' RETURN n
"@ |Out-GridView

#Remove Connection
Remove-Neo4jRelationship -LeftQuery "MATCH (left:Topic) WHERE left.Name = 'PowerShell'" `
    -Type 'TopicOf' `
    -Properties @{
    Connection = $True
}

Invoke-Neo4jQuery -Query @"
    MATCH (n) WHERE n.Type =~ 'Prevention.*' RETURN n
"@ |Out-GridView

Invoke-Neo4jQuery -Query @"
    MATCH (n) WHERE n.Name =~ 'Prevention.*' RETURN n
"@ |Out-GridView
#Query: MATCH (n) WHERE n.Done = 'false' RETURN n Order by n.CalculatedValue ASC          

#endregion

#region filling with data

#List of the currently implemented demonstration worksheets
$workSheets = 'PowerShell', 'Securing Privileged Access', 'Modernizing Environment'

#Going through all known worksheets - importing topics and data - create relationships
#a worksheet is a topic
foreach ($workSheet in $workSheets) {
    #Retrieve the worksheet data from the Excel file
    $excelDataPS = Get-ExcelDataFromWorksheet -folder $folder -workSheet $workSheet 

    #Create the nodes for the topics
    $excelDataPS.Where{$_.Information -eq 'Topic'} | New-Neo4jNode -Label Topic  #-Passthru

    #Creates the nodes for the technical controls
    $excelDataPS.Where{$_.Information -ne 'Topic'} | New-Neo4jNode -Label TechnalSecurityControl #-Passthru

    #Relationships for every topic
    New-Neo4jRelationship -LeftQuery "MATCH (left:TechnalSecurityControl) WHERE left.Tag =~ '$worksheet.*'" `
        -RightQuery "MATCH (right:Topic) WHERE right.Name = '$workSheet'" `
        -Type 'TopicOf' `
        -Properties @{
        Connection = $True
    }
}

#Adding types to graph
$types = ($excelDataPS + $excelDataSPA + $excelDataME).Type | Select-Object -Unique 
$types | Select-Object @{"n" = 'Name'; "e" = {$_}} | New-Neo4jNode -Label Type #-Passthru

#Relationship for Types
foreach ($type in $types) {    
    New-Neo4jRelationship -LeftQuery "MATCH (left:TechnalSecurityControl) WHERE left.Type =~ '$type.*'" `
        -RightQuery "MATCH (right:Type) WHERE right.Name = '$type'" `
        -Type 'TypeOf' `
        -Properties @{
        Connection = $True
    }
}

#endregion


# See what we have
Invoke-Neo4jQuery -Query @"
MATCH (n)
RETURN n;
"@ | Out-GridView

#region clear

#Clear data in Neo4j

# This removes nodes, relationships, constraints, and indexes
Clear-Neo4j

# Alternatively, just clear nodes and relationships:
Invoke-Neo4jQuery -Query @"
MATCH (n)
DETACH DELETE n;
"@

Invoke-Neo4jQuery -Query @"
MATCH (n)
OPTIONAL MATCH (n)-[r]-()
WITH n,r LIMIT 50000
DELETE n,r
RETURN count(n) as deletedNodesCount
"@

#endregion

#endregion