
# get all interesting values from the list
Invoke-Neo4jQuery -Query @"
MATCH (n) 
WHERE n.Done = 'false' 
RETURN n 
Order by n.CalculatedValue ASC
"@ |Out-GridView

# get all interesting values from the list fot 'Prevention'
Invoke-Neo4jQuery -Query @"
MATCH (n) 
WHERE n.Done = 'false' AND n.Type = 'Prevention'
RETURN n 
Order by n.CalculatedValue ASC
"@ |Out-GridView

# get all interesting values from the list fot 'Detection'
Invoke-Neo4jQuery -Query @"
MATCH (n) 
WHERE n.Done = 'false' AND n.Type = 'Detection'
RETURN n 
Order by n.CalculatedValue ASC
"@ |Out-GridView

# get all interesting values from the list fot 'Respond'
Invoke-Neo4jQuery -Query @"
MATCH (n) 
WHERE n.Done = 'false' AND n.Type = 'Respond'
RETURN n 
Order by n.CalculatedValue ASC
"@ |Out-GridView

#Query: MATCH (n) WHERE n.Done = 'false' RETURN n Order by n.CalculatedValue ASC          
