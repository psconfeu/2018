Preconditions:

	PowerShell modules (in PSNeo4j.ps1):
	- Importexcel
	- PSNeo4j

	Tools:
	- Neo4j (https://neo4j.com/download/)
	- Java JRE 8/10 (http://www.oracle.com/technetwork/java/javase/downloads/index.html)
