#Preconditions
Install-Module PSReflect-Functions 
Import-Module PSReflect-Functions 

#Loading function
. .\New-InjectedThread.ps1

#Execution
New-InjectedThread -Process (Get-Process notepad)