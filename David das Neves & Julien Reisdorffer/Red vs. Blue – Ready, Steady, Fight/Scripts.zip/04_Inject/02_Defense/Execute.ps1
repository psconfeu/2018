
#Loading function
. .\Gew-InjectedThread.ps1

#Execution
Gew-InjectedThread 