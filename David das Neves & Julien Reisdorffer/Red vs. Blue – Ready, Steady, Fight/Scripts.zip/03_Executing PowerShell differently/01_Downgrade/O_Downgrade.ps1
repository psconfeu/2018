#Hiding against logging
powershell.exe -version 2 Get-Service