# http://www.leeholmes.com/blog/2017/03/17/detecting-and-preventing-powershell-downgrade-attacks/

# As a detection mechanism, the Windows PowerShell classic event log has event ID 400. 
# This is the Engine Lifecycle event, and includes the Engine Version. 
# Here is an example query to find lower versions of the PowerShell engine being loaded:

Get-WinEvent -LogName "Windows PowerShell" |
    Where-Object Id -eq 400 |
    Foreach-Object {
        $version = [Version] ($_.Message -replace '(?s).*EngineVersion=([\d\.]+)*.*','$1')
        if($version -lt ([Version] "5.0")) { $_ }
}

#v2 GAC MSIL 
powershell -version 2 -noprofile -command "$(Get-Item ([PSObject].Assembly.Location)).VersionInfo"

#v4 GAC MSIL
powershell -noprofile -command "(Get-Item ([PSObject].Assembly.Location)).VersionInfo | Select *"

#v2 Native
powershell -version 2 -noprofile -command "(Get-Item $(Get-Process -id $pid -mo | ? { $_.FileName -match 'System.Management.Automation.ni.dll' } | % { $_.FileName })).VersionInfo"

#v4 Native
powershell -noprofile -command "(Get-Item $(Get-Process -id $pid -mo | ? { $_.FileName -match 'System.Management.Automation.ni.dll' } | % { $_.FileName })).VersionInfo"
