# https://gist.github.com/mattifestation/fa2e3cea76f70b1e2267
# modified
#region Scriptblocks that will execute upon alert trigger
$PSHostProcessStarted = {
    $Event = $EventArgs.NewEvent

    $LoadTime = [DateTime]::FromFileTime($Event.TIME_CREATED)
    $PID = $Event.ProcessID

    # Note: The host process may already have exited by now.
    # This is a better method for catching any PowerShell host process though.
    $ProcInfo = Get-WmiObject -Query "SELECT * FROM Win32_Process WHERE ProcessId=$PID" -ErrorAction SilentlyContinue

    $CommandLine = $ProcInfo.CommandLine
    $ProcessName = $ProcInfo.Name

    #Define whitelisted host processes
    $whiteListedProcesses = 'powershell_ise.exe','powershell.exe'
    if ($ProcessName -in $whiteListedProcesses) {
        $state = 'good'
    }
    else {
        $state = 'bad'
    }
    
    #Visualize with write-warning / alternatively write Eventlogs or raise alters
    Write-Warning @"
SIGNATURE: Host PowerShell process started

Date/Time: $LoadTime
Process ID: $PID
Process Name: $ProcessName
Command Line: $CommandLine
State: $state
"@
}
#endregion


#region Alert definition

# Trigger on any process that loads the PowerShell DLL - System.Management.Automation[.ni].dll
$PSHostProcArgs = @{
    Query = 'SELECT * FROM Win32_ModuleLoadTrace WHERE FileName LIKE "%System.Management.Automation%.dll%"'
    Action = $PSHostProcessStarted
    SourceIdentifier = 'PowerShellHostProcessStarted'
}

#endregion


#region Alert registration
Register-WmiEvent @PSHostProcArgs
#endregion