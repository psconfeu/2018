 
C:\Program Files\PowerShell\6.0.0-rc\pwsh.exe