﻿break;

##########################################
#1st example
((47,65,74,'2d',53,65,72,76,69,63,65,20,42,49,54,53)|fOREach{([cONvERT]::Toint16(([sTRING]$_),16)-as[ChaR])})-jOin''|&( $eNV:coMSpec[4,24,25]-JOIn'')

#Splitting into parts
((47,65,74,'2d',53,65,72,76,69,63,65,20,42,49,54,53)|fOREach{([cONvERT]::Toint16(([sTRING]$_),16)-as[ChaR])})-jOin''
($eNV:coMSpec[4,24,25]-JOIn'')
$eNV:coMSpec

##########################################
#2nd example
inVOkE-ExpREssIOn(-joIn( '71!101x116n45&83x101n114&118V105V99V101V32&66W73V84z83'-SPLit'W' -spLiT'!'-spLiT '&'-sPliT 'J' -spLit'V' -spliT 'x'-SplIt 'n'-SpliT 't'-SpLiT'Y' -SpliT'z' | fOReAcH {([cHaR][Int] $_) } ) )
#Splitting into parts
-joIn( '71!101x116n45&83x101n114&118V105V99V101V32&66W73V84z83'-SPLit'W' -spLiT'!'-spLiT '&'-sPliT 'J' -spLit'V' -spliT 'x'-SplIt 'n'-SpliT 't'-SpLiT'Y' -SpliT'z' | fOReAcH {([cHaR][Int] $_) } )


##########################################
#3rd example
([RUntiMe.interOpsERvICes.MARshaL]::([RunTiMe.iNtErOPseRvIceS.mARShal].gETmemBerS()[4].NAmE).INvOKe([RUNTImE.inTeRoPSERvICes.mARshaL]::secUREstriNgtoGLObaLALLOcUniCoDE($('76492d1116743f0423413b16050a5345MgB8ADYAYgBIAGQAWABwAGcAbgBYAG0ARABSAFoASQBkAEgAcwAzAFgAWQAxAFEAPQA9AHwANgA2AGQAMwBiADIAOQA2ADgAOABmADkAYQA2ADMAOQAwAGQAOAA1AGIAMQA1AGQAYQAxADcAYQA2AGMAOQA1ADMAYQA0AGQAYwA3ADgAZABjAGUAMgAwAGYANwAyADAAMQA1ADcAZQAyAGEAYQBmADkAZQAxADMAOQAyADgAOAAxAGUAZQAyADEAOQBmADkAMQBkADkANgAzADAAOAA3ADQAZQA0AGIANgA0AGIAZgBkADIAMwA4ADgAYgA3ADUA'|convERTTo-SecuREsTRINg  -KEy 203,44,105,6,209,29,205,9,226,126,34,92,19,130,12,164,96,90,234,90,131,187,101,158,136,170,213,99,230,174,102,106) ) ))|IeX
#Splitting into parts
([RUntiMe.interOpsERvICes.MARshaL]::([RunTiMe.iNtErOPseRvIceS.mARShal].gETmemBerS()[4].NAmE).INvOKe([RUNTImE.inTeRoPSERvICes.mARshaL]::secUREstriNgtoGLObaLALLOcUniCoDE($('76492d1116743f0423413b16050a5345MgB8ADYAYgBIAGQAWABwAGcAbgBYAG0ARABSAFoASQBkAEgAcwAzAFgAWQAxAFEAPQA9AHwANgA2AGQAMwBiADIAOQA2ADgAOABmADkAYQA2ADMAOQAwAGQAOAA1AGIAMQA1AGQAYQAxADcAYQA2AGMAOQA1ADMAYQA0AGQAYwA3ADgAZABjAGUAMgAwAGYANwAyADAAMQA1ADcAZQAyAGEAYQBmADkAZQAxADMAOQAyADgAOAAxAGUAZQAyADEAOQBmADkAMQBkADkANgAzADAAOAA3ADQAZQA0AGIANgA0AGIAZgBkADIAMwA4ADgAYgA3ADUA'|convERTTo-SecuREsTRINg  -KEy 203,44,105,6,209,29,205,9,226,126,34,92,19,130,12,164,96,90,234,90,131,187,101,158,136,170,213,99,230,174,102,106) ) ))


##########################################
#Obfuscation Detection by Exploit Guard
Add-MpPreference -AttackSurfaceReductionRules_Ids 5BEB7EFE-FD9A-4556-801D-275E5FFC04CC -AttackSurfaceReductionRules_Actions Enabled
