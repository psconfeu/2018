﻿class ExternalConfiguration {
    [String]
    $Cname

    [String]
    $Description
    
    [String[]]
    $OtherCnames
    
    [String]        
    $TechnicalOwner
}
