function Pause{
   $null = Read-Host 'Press Enter to continue…'
}